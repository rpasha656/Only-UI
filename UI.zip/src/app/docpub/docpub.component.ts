import { Component, Inject, ViewChild } from '@angular/core';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { FileListingComponent } from './filelisting.component';
import { FileMetadataService } from './filemetadata.service';
@Component({
    moduleId: module.id,
    selector: 'as-docpub',
    template: require('./docpub.component.html')
})
export class DocpubComponent {
    public selectedPlanName: string;
    public showParent: Boolean;
    @ViewChild(FileListingComponent) fileListingComponent: FileListingComponent;
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string,
        private filemetadataService: FileMetadataService) {
        this.selectedPlanName = 'Select';
        this.fileListingComponent = new FileListingComponent(filemetadataService);
        this.showParent = true;
    }
    getFileListing(planName: string) {
        this.fileListingComponent.getFileMetadatalisting(planName);
    }
}
